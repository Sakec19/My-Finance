/* MyFinance offline-first snapshot synchronization. No secrets embedded. */
(()=>{'use strict';
const cfg=window.MYFINANCE_CLOUD_CONFIG||{};
const configured= /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.url||'') && !!cfg.publishableKey;
const bridge=window.MyFinanceBridge;
const byId=x=>document.getElementById(x);
const setStatus=s=>{byId('cloudStatus').textContent=s};
let session=null,revision=null,initialized=false,dirty=false,running=false,timer=null;
const base=(cfg.url||'').replace(/\/$/,'');
const tokenStore='myfinance-cloud-session';
function headers(token){const h={'apikey':cfg.publishableKey,'Content-Type':'application/json'};if(token||session?.access_token)h.Authorization='Bearer '+(token||session.access_token);return h}
function authHeaders(){return headers(session?.access_token)}
function failText(err){return err?.message||String(err)}
async function request(path,options={}){
 const res=await fetch(base+path,{...options,headers:{...headers(),...(options.headers||{})}});
 if(!res.ok){let message='HTTP '+res.status;try{const data=await res.json();message=data.msg||data.message||data.error_description||data.error||message}catch{}throw Error(message)}
 return res.status===204?null:res.json();
}
async function refreshSession(){
 if(!session)throw Error('Sign in first');
 if(Date.now()<session.expires_at-60000)return;
 if(!session.refresh_token){logout();throw Error('Session expired. Sign in again.')}
 const next=await request('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:JSON.stringify({refresh_token:session.refresh_token})});
 setSession(next);
}
function setSession(data){
 if(!data?.access_token||!data?.user?.id)throw Error('Incomplete sign-in response');
 session={...data,expires_at:Date.now()+(data.expires_in||3600)*1000};
 try{sessionStorage.setItem(tokenStore,JSON.stringify(session))}catch{}
 byId('cloudLogin').classList.add('hidden');byId('cloudActions').classList.remove('hidden');
 byId('cloudConnection').textContent='Signed in';
 setStatus('Signed in as '+session.user.email+'. Select Sync now or Restore from cloud to start.');
}
function logout(){session=null;initialized=false;revision=null;dirty=false;clearTimeout(timer);try{sessionStorage.removeItem(tokenStore)}catch{}byId('cloudLogin').classList.remove('hidden');byId('cloudActions').classList.add('hidden');byId('cloudConnection').textContent=configured?'Not signed in':'Not configured';setStatus('Local data stays on this device.');}
async function auth(email,password,signup){
 if(!configured)throw Error('Cloud is not configured. Follow README first.');
 if(!email||password.length<8)throw Error('Enter a valid email and password of 8 or more characters.');
 const path=signup?'/auth/v1/signup':'/auth/v1/token?grant_type=password';
 const result=await request(path,{method:'POST',body:JSON.stringify({email,password})});
 byId('cloudPassword').value='';
 if(result?.access_token)setSession(result);
 else setStatus('Account created. Check your email to confirm, then sign in.');
}
async function readCloud(){
 await refreshSession();
 const rows=await request('/rest/v1/myfinance_snapshots?select=payload,revision,updated_at&user_id=eq.'+encodeURIComponent(session.user.id),{headers:authHeaders()});
 return rows?.[0]||null;
}
async function createCloud(payload){
 const rows=await request('/rest/v1/myfinance_snapshots',{method:'POST',headers:{...authHeaders(),'Prefer':'return=representation'},body:JSON.stringify({user_id:session.user.id,payload,revision:1})});
 if(!rows?.[0])throw Error('Cloud create did not return a saved record');
 revision=rows[0].revision;dirty=false;initialized=true;setStatus('Synced to cloud. Revision '+revision+'.');
}
async function updateCloud(payload){
 const rows=await request('/rest/v1/myfinance_snapshots?user_id=eq.'+encodeURIComponent(session.user.id)+'&revision=eq.'+revision,{method:'PATCH',headers:{...authHeaders(),'Prefer':'return=representation'},body:JSON.stringify({payload,revision:revision+1,updated_at:new Date().toISOString()})});
 if(rows?.length!==1){initialized=false;throw Error('Conflict: cloud changed on another device. Choose Sync now to review before any overwrite.');}
 revision=rows[0].revision;dirty=false;setStatus('Synced securely over HTTPS. Revision '+revision+'.');
}
function applyCloud(row){
 if(!row?.payload)throw Error('Cloud record is invalid');
 initialized=false;bridge.importSnapshot(row.payload);revision=row.revision;dirty=false;initialized=true;
 setStatus('Restored from cloud. Revision '+revision+'. Reminders refreshed.');
}
async function firstSync(restoreOnly){
 const remote=await readCloud(),localHasData=bridge.hasLocalData();
 if(!remote){
  if(restoreOnly)throw Error('No cloud backup found for this account.');
  if(!confirm('No cloud backup exists. Upload your current local MyFinance data as your first cloud backup?'))return;
  await createCloud(bridge.exportSnapshot());return;
 }
 if(restoreOnly){if(!confirm('Replace ALL local financial data with the cloud copy? Export a JSON backup first.'))return;applyCloud(remote);return;}
 if(!localHasData){if(confirm('Cloud data exists. Restore it to this empty device?'))applyCloud(remote);return;}
 if(!confirm('Both this device and the cloud contain data. Restore cloud data to this device? Cancel to leave both unchanged. Export backups first.'))return;
 applyCloud(remote);
}
async function syncNow(restoreOnly=false){
 if(running)return;running=true;
 try{
  if(!navigator.onLine){setStatus('Offline: your data remains saved locally.');return}
  if(!session)throw Error('Sign in to enable cloud sync.');
  if(!initialized){await firstSync(restoreOnly);return}
  const remote=await readCloud();
  if(!remote||remote.revision!==revision){initialized=false;setStatus('Sync paused: cloud changed on another device. Use Sync now to review, or Restore from cloud. No data was overwritten.');return}
  if(restoreOnly){if(confirm('Replace local data with the cloud snapshot?'))applyCloud(remote);return}
  if(dirty){const snapshot=bridge.exportSnapshot();await updateCloud(snapshot);if(JSON.stringify(snapshot)!==JSON.stringify(bridge.exportSnapshot())){dirty=true;clearTimeout(timer);timer=setTimeout(()=>syncNow(),200)}}
  else setStatus('Up to date · cloud revision '+revision+'.');
 }catch(e){setStatus('Sync not completed: '+failText(e));console.warn('Cloud sync:',failText(e))}
 finally{running=false}
}
function onLocalSave(){if(!session||!initialized)return;dirty=true;clearTimeout(timer);timer=setTimeout(()=>syncNow(),1800)}
window.MyFinanceCloud={onLocalSave};
byId('cloudConnection').textContent=configured?'Ready for sign-in':'Setup required';
setStatus(configured?'Sign in to connect your private cloud backup.':'Cloud inactive: add your Supabase URL and publishable key to cloud-config.js.');
byId('cloudSignIn').onclick=()=>auth(byId('cloudEmail').value.trim(),byId('cloudPassword').value,false).catch(e=>setStatus(failText(e)));
byId('cloudSignUp').onclick=()=>auth(byId('cloudEmail').value.trim(),byId('cloudPassword').value,true).catch(e=>setStatus(failText(e)));
byId('cloudSyncNow').onclick=()=>syncNow();
byId('cloudRestore').onclick=()=>syncNow(true);
byId('cloudSignOut').onclick=logout;
if(!configured){byId('cloudSignIn').disabled=true;byId('cloudSignUp').disabled=true;}
else{
 try{const saved=JSON.parse(sessionStorage.getItem(tokenStore)||'null');if(saved?.access_token&&saved?.user?.id){session=saved;byId('cloudLogin').classList.add('hidden');byId('cloudActions').classList.remove('hidden');byId('cloudConnection').textContent='Signed in';setStatus('Signed in. Select Sync now to reconnect this session.')}}catch{}
}
window.addEventListener('online',()=>{if(initialized&&dirty)syncNow()});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&initialized)syncNow()});
setInterval(()=>{if(initialized&&session&&navigator.onLine)syncNow()},60000);
})();
