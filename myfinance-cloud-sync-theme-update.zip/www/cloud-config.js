// Set these to your DEDICATED MyFinance Supabase project values.
// Only the publishable (or legacy anon) key is permitted here; NEVER a secret/service_role key.
window.MYFINANCE_CLOUD_CONFIG = {
  url: '', // Example: https://YOUR_PROJECT_REF.supabase.co
  publishableKey: ''
};
