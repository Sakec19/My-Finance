MyFinance Investments update (existing static Capacitor app)

This update was made against a previously shared MyFinance index.html.
Back up your CURRENT www/index.html before replacing it. If your GitHub copy has evolved, merge rather than overwrite.

Install:
1. In your Windows folder C:\Users\mehta\Downloads\finance-ios, back up www\index.html.
2. Copy the supplied index.html into www\index.html.
3. Run: git diff -- www/index.html
4. Run: npm run build
5. Run: npx cap sync ios
6. Check the app in a browser and in the Codemagic simulator.
7. When satisfactory: git add www/index.html && git commit -m "Add offline investments dashboard" && git push origin main

What's new:
- Investments navigation tab and editable investment holdings.
- Types: Stock, ETF, Mutual Fund, Bond, Crypto, Other.
- Manual quantities, average cost, current unit price, and brokerage/account notes.
- Portfolio value, cost basis, unrealized gains/losses, return on cost, asset-type allocation.
- CSV export for investments; JSON full backup/restore including holdings; earlier backups still load.
- Existing income, expenses, cards, savings goals, and payment scheduling retained.

Important:
- Manual current prices, not a live market feed. USD amounts only.
- No broker connectivity or trade history; gains are UNREALIZED position value minus average cost basis.
- Purchases don't debit bank balances or count as spending, and bank-account transfers are not automatically recorded.
- Do not treat holdings as synchronized with a broker; reconcile separately.
- Full backup via Backup & settings before replacing the app.
