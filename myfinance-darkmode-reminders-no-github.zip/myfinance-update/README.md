# MyFinance — Dark Mode and Credit Card Reminders

This incremental update is based on the earlier MyFinance version with Investments. It is not a complete iOS project. Back up your current `www/index.html` and export your MyFinance data before applying it. Merge any newer changes rather than overwriting them.

## Features
- Light / Dark / Follow Device appearance settings.
- iOS local credit-card payment notifications for planned installments and due dates, subject to permission and system scheduling limits.
- Reminder schedules refresh when supported card/payment data changes or the app reopens.
- Existing investments and finance functionality retained from the update base.

## Manual Windows installation (no GitHub automation)
1. Extract this ZIP.
2. Back up your current `finance-ios/www/index.html` before replacing anything.
3. After reviewing and merging current changes, copy the update's `index.html` to `finance-ios/www/index.html`.
4. In a PowerShell terminal opened at `finance-ios`, run:

   ```powershell
   npm install '@capacitor/local-notifications@^8' --save
   npm run build
   npx cap sync ios
   ```

5. Test the updated web application and native iOS build before distributing an update.

## Notes
- The included `myfinance-embedded.js` is an extracted JavaScript helper for inspection/syntax checking; the updated `index.html` already embeds the app's scripts.
- Notifications require explicit user permission. iOS limits pending local notifications; opening the app refreshes its rolling schedule.
- No payment is initiated by a reminder.
- The ZIP intentionally contains **no GitHub deployment script** or automatic upload instructions.
