-- Run ONLY in a dedicated MyFinance Supabase project.
-- Application uses a per-user snapshot, revision counter, and row-level security.
create table if not exists public.myfinance_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1 check(revision > 0),
  updated_at timestamptz not null default now()
);
alter table public.myfinance_snapshots enable row level security;
revoke all on public.myfinance_snapshots from anon;
grant select, insert, update on public.myfinance_snapshots to authenticated;
create policy "finance_owner_select" on public.myfinance_snapshots
 for select to authenticated using ((select auth.uid()) = user_id);
create policy "finance_owner_insert" on public.myfinance_snapshots
 for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "finance_owner_update" on public.myfinance_snapshots
 for update to authenticated using ((select auth.uid()) = user_id)
 with check ((select auth.uid()) = user_id);
-- Never disable RLS or use a secret/service_role key in www/.
