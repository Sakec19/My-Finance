# MyFinance — visible appearance selector + optional cloud sync

## What changed
- Prominent **Appearance** selector in the header: System / Light / Dark, plus the existing selector in Backup & Settings.
- Cloud sync panel in Backup & Settings, with email/password sign-in, initial upload/restore confirmation, auto-sync after local edits, and revision-based conflict pause.
- Investments, payment reminders, local storage and current data model remain in the app.
- No GitHub deployment automation is included.

## Install safely
1. Export a full JSON backup from your current app.
2. Back up your current `www/index.html` and **compare/merge** before replacing it: this package is based on the earlier MyFinance investment + reminder version, not necessarily your newest GitHub commit.
3. Copy the THREE files in `www/` to the same folder in your project: `index.html`, `cloud-config.js`, `cloud-sync.js`. Keep your other assets untouched.
4. Test the visible Appearance selector in a browser. Deploy with your normal process: `npm run build` and `npx cap sync ios` (native sync runs in macOS cloud builder).

## Activate cloud syncing (requires a new project; NOT ACTIVE by default)
1. Create a **separate** Supabase project for MyFinance at https://supabase.com/dashboard. Do NOT use an existing JobPilot database.
2. In that project's SQL Editor, run `database-setup.sql`. Ensure the `public` schema is exposed by Data API, and verify the RLS policies. Enable email authentication; configure verification and password policy in Supabase Auth settings.
3. In Project Settings / API, copy your project's URL and **publishable key** (legacy anon key also works); paste them in `www/cloud-config.js`. Never paste secret/service_role keys.
4. Open MyFinance > Backup & settings > Cloud sync, create an account and verify email if required, then sign in.
5. Export a local JSON backup. Click **Sync now** to initialize the cloud data (confirmation required). For a new empty device, sign in and restore from cloud.

## How sync behaves
- Financial records stay local when offline, cloud is optional. When logged in and initialized, local edits upload after 1.8 seconds, if online, and the app checks again on foreground and every minute.
- Cloud data is scoped by Supabase Auth user ID and database RLS; HTTPS protects transfer. **The cloud stores the JSON payload in server-readable form; this is NOT end-to-end encrypted**. Do not store card numbers, banking passwords or other secrets in notes.
- This initial release uses whole-account snapshots, not field-by-field merges. When cloud is changed by another device, syncing stops and asks you to explicitly restore or reconcile backups. Conflicts are never silently overwritten.
- Signing out does not erase local MyFinance data. Session tokens use tab/session storage rather than persistent device storage; reopening the app may require another sign-in.
- Sync occurs while the app is open/foreground; iOS background sync is not guaranteed.
- Verify account isolation (two test users), offline changes, conflicting edits, and restore in a staging project before using real financial data.

## Deployment
There is **no GitHub push or deployment script** in this package. Your current GitHub and Codemagic setup remains unchanged.
