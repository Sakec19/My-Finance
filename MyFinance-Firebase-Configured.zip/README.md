# MyFinance — Firebase Cloud Sync + Theme Selection

This update replaces the previous **Supabase cloud-sync integration** with Firebase Authentication and Cloud Firestore. It retains the investments, credit card reminder code, and both Appearance selectors (in the app header and Backup & settings). **No GitHub deployment automation.**

## Before installing

1. Export a JSON backup from the currently installed MyFinance app, and keep a copy outside the device.
2. Make a separate backup of the current `www/index.html`. This package is derived from the previous cloud/theme release; **compare and merge if you have newer local changes**.
3. Copy the three files from `www/` into your project's `www/` folder. Remove/stop including `cloud-config.js` and `cloud-sync.js` (Supabase) after confirming Firebase works. Existing `ios/` assets, images, `package.json`, and notification plugin remain untouched.
4. Firebase project `myfinance-43109` has already been created on Spark in us-east4; do NOT create another project.
5. Firebase Web App `MyFinance Web` is registered and `www/firebase-config.js` is populated with its PUBLIC settings. Never use a service account key or backend private secret.
6. Email/Password sign-in has been enabled. Configure email verification, password policy, and account-recovery options before production use.
7. Firestore was created in production mode in `us-east4`, and the included owner-only `firestore.rules` were PUBLISHED and verified using three read simulations (unauthenticated deny, other-user deny, owner allow). Future rule changes must be deployed and re-tested.
8. Run your normal Windows build check (`npm run build`). On macOS cloud builder, run `npx cap sync ios` followed by the existing iOS workflow. Do not try to build Xcode locally on Windows.
9. In MyFinance > Backup & settings > Cloud sync, sign up and sign in, then select **Sync now**. Confirm the first upload. On an empty second device, sign in and choose **Restore from cloud**.

## Behavior and limits

- User data is saved locally first, unchanged from your previous app. Cloud sync is optional and only runs while signed in and while the app is open/foreground with connectivity. No guarantee of iOS background sync.
- Data uses `users/{firebaseAuthUid}/private/financeSnapshot` with Firestore rules limiting access to that authenticated user.
- A full account snapshot is stored in **one Firestore document**: the Firestore document size limit applies (1 MiB), so future upgrades should migrate to per-transaction records for large histories.
- The implementation uses revision-checked Firestore transactions when online; if another device changed the cloud backup, uploading is paused rather than silently overwriting it. First-use and cloud restoration require user confirmation. This is backup-style sync, **not a real-time per-record merge**.
- Data is protected in transit and by Firebase's server-side security and access rules. It is **not end-to-end encrypted**. Avoid full card numbers, passwords, CVVs or other secrets in notes.
- The Firebase browser SDK loads via pinned Google CDN module URLs. If the network/SDK cannot load, local finance tracking still works, but cloud sign-in/sync does not. For a fully self-contained native app, bundle Firebase with npm+esbuild and package the JS locally before release.
- A signed-in browser session may be remembered on this device. Do not enable persistent shared-device access for sensitive data. Test Safari/Capacitor WKWebView behavior and the iOS privacy screen lock.
- `npm run build` in this older static project only prints a message. It is **not** a comprehensive syntax/behavior test. Validate actual app behavior in a simulator and real device.
- Cloud synchronization costs depend on Firebase quotas; Firebase Spark has a no-cost allowance, not unlimited storage or operations.

## Required tests before real financial data

- Test sign-in and first backup with **dummy records** and confirm Firestore document appears under the correct UID.
- Test another UID cannot read/write that first account's data, using Firestore Rules playground or emulator.
- Test offline local edits, reconnect and sync; repeat on two test devices and trigger a conflict. Confirm no overwrite.
- Test app restart, dark/light/system theme, investments, card reminders, and restore after export.
- Check Firebase security rules and authentication error handling before production.

## Files

- `www/index.html` — same MyFinance UI and theme controls, now loading Firebase modules.
- `www/firebase-config.js` — fill in your own Firebase Web App config.
- `www/firebase-sync.js` — authenticated backup-style Firestore sync adapter.
- `firestore.rules` — owner-only Firestore access rules.

Firebase project and production security-rule configuration have been completed in Firebase Console. No application files have been pushed to GitHub and no real financial records have been synchronized or uploaded. Cloud sync is not active on your installed app until these updated web files are installed and a MyFinance account signs in. This remains a backup-style snapshot sync and not per-record two-way merge.
